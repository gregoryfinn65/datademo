﻿
Partial Class Mybooksrpt
    Inherits System.Web.UI.Page

End Class
